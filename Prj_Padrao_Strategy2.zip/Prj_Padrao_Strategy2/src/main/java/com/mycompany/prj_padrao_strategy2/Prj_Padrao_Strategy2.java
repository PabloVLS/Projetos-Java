package com.mycompany.prj_padrao_strategy2;

/**
 *
 * @author IFTM
 */
public class Prj_Padrao_Strategy2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
