
package formularios;


public class FormPrincipal extends javax.swing.JFrame {

    /**
     * Creates new form FormPrincipal
     */
    public FormPrincipal() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        mniCalcComun = new javax.swing.JMenuItem();
        mniCalcSegGrau = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        mniSair = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Principal");

        jMenu1.setText("Calculadoras");

        mniCalcComun.setText("Calculadora Comun");
        mniCalcComun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniCalcComunActionPerformed(evt);
            }
        });
        jMenu1.add(mniCalcComun);

        mniCalcSegGrau.setText("Calculadora Segundo Grau");
        mniCalcSegGrau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniCalcSegGrauActionPerformed(evt);
            }
        });
        jMenu1.add(mniCalcSegGrau);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Opções");

        mniSair.setText("Sair");
        mniSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniSairActionPerformed(evt);
            }
        });
        jMenu2.add(mniSair);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 277, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void mniCalcComunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniCalcComunActionPerformed
        new FormCalcComun().setVisible(true);
    }//GEN-LAST:event_mniCalcComunActionPerformed

    private void mniCalcSegGrauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniCalcSegGrauActionPerformed
        new FormCalcEqSegGrau().setVisible(true);
    }//GEN-LAST:event_mniCalcSegGrauActionPerformed

    private void mniSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniSairActionPerformed
        System.exit(0);
    }//GEN-LAST:event_mniSairActionPerformed

    public static void main(String args[]) {
   
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem mniCalcComun;
    private javax.swing.JMenuItem mniCalcSegGrau;
    private javax.swing.JMenuItem mniSair;
    // End of variables declaration//GEN-END:variables
}
