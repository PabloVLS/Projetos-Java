
package com.mycompany.prj_padrao_observer;

/**
 *
 * @author PAblo
 */
public interface Observer {
    public void update(float temp, float humidity, float pressure);
}
