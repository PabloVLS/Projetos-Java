package com.mycompany.prj_padrao_observer;

/**
 *
 * @author IFTM
 */
public interface DisplayElement {
    public void display();
}
